import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.TreeSet;
import java.util.stream.Collectors;

public class Test {
    public static void main(String[] args) {
        List<String> list = new ArrayList<>();
        list.add("AWS");
        list.add("Java");
        list.add("AWS");
        list.add("Java");
        list.add("Kafka");

        Set<String> set = new TreeSet<>();
        List<String> newList = list.stream().sorted().collect(Collectors.toList());

        System.out.println(newList);

    }
}