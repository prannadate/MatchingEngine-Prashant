package test;

public class ToeplitzMatrix {
    public static boolean isToeplitzMatrix(int[][] matrix) {
        int m = matrix.length;
        int n = matrix[0].length;

        for(int i=0; i<m-1; i++){
            for(int j=0; j<n-1; j++){
                if(matrix[i][j] != matrix[i+1][j+1]){
                    return false;
                }
            }
        }

        return true;
    }

    public static void main(String[] args) {

        // Test case 1
        int[][] matrix1 = {
                {1, 2, 3, 4},
                {5, 1, 2, 3},
                {9, 5, 1, 2}
        };
        System.out.println(isToeplitzMatrix(matrix1));  // Output: true

        // Test case 2
        int[][] matrix2 = {
                {1, 2},
                {2, 2}
        };
        System.out.println(isToeplitzMatrix(matrix2));  // Output: false
    }
}
