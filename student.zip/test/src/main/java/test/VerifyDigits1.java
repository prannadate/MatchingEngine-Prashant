package test;

//    For line = "123_456_789", the output should be
//    solution(line) = true;
//    For line = "16#123abc#", the output should be
//    solution(line) = true;
//    For line = "10#123abc#", the output should be
//    solution(line) = false;
//    For line = "10#10#123ABC#", the output should be
//    solution(line) = false;
public class VerifyDigits1 {

     static boolean solution(String line) {
        boolean atLeastOneDigit = false;

        if(line.charAt(line.length()-1) == '#'){
            int base = 0;
            int i = 0;

            while(i < line.length() -1 && line.charAt(i) != '#') {
                if('0' <= line.charAt(i) && line.charAt(i) <= '9') {
                    base = base * 10 + line.charAt(i) - '0';
                } else {
                    return false;
                }
                i++;
            }

            if(base < 2 || base > 16) {
                return false;
            }

            i++;

            while(i < line.length() -1){
                if(line.charAt(i) != '_'){
                    int digit = -1;

                    if('a' <= line.charAt(i) && line.charAt(i) <= 'f') {
                        digit = line.charAt(i) - 'a' + 10;
                    }
                    if('A' <= line.charAt(i) && line.charAt(i) <= 'F') {
                        digit = line.charAt(i) - 'A' + 10;
                    }
                    if('0' <= line.charAt(i) && line.charAt(i) <= '9') {
                        digit = line.charAt(i) - '0';
                    }
                    if(digit >=0 && digit < base) {
                        atLeastOneDigit = true;
                    } else {
                        return false;
                    }
                }
                i++;
            }
        } else {
            for
            (int i=0; i< line.length(); i++) {
                if('0' <= line.charAt(i) && line.charAt(i) <= '9') {
                    atLeastOneDigit = true;
                } else {
                    return false;
                }
            }
        }

        return atLeastOneDigit;
    }

    public static void main(String args[]){
        System.out.println("Result - " + solution("16#123abc#"));
    }

}
