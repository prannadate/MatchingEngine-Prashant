package test;

import java.util.HashMap;

public class SongPairsDivisibleBy60 {
    public int numPairsDivisibleBy60(int[] time) {
        int pairCount = 0;

        HashMap<Integer, Integer> remainderMap = new HashMap<>();

        for(int t: time){
            int remainder = t % 60;
            int complement = (60 - remainder) % 60;
            pairCount += remainderMap.getOrDefault(complement, 0);
            remainderMap.put(remainder, remainderMap.getOrDefault(remainder, 0)+1);
        }


        return pairCount;
    }

    public static void main(String[] args) {
        SongPairsDivisibleBy60 solution = new SongPairsDivisibleBy60();
        int[] time = {30, 20, 150, 100, 40};
        System.out.println(solution.numPairsDivisibleBy60(time)); // Output: 3
    }
}