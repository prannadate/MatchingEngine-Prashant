package test;

public class NonConsecutiveOnes {
    public static int findIntegers(int n) {

        String binary = Integer.toBinaryString(n);
        int len = binary.length();

        int[] dp = new int[len+1];

        dp[0] = 1;
        dp[1] = 2;

        for(int i = 2; i <= len; i++) {
            dp[i] = dp[i-1] + dp[i-2];
        }

        int count = 0; int prevBit = 0;

        for(int i = 0; i < len; i++) {
            if(binary.charAt(i) == '1') {
                count += dp[len - i -1];

                if(prevBit == 1) return count;

                prevBit = 1;
            } else {
                prevBit = 0;
            }
        }
        return count + 1;
    }

    public static void main(String[] args) {
        System.out.println(findIntegers(5));  // Output: 5
        System.out.println(findIntegers(10)); // Output: 8
        System.out.println(findIntegers(100)); // Output: 34
    }
}
