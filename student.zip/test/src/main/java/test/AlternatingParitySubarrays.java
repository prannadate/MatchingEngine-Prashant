package test;

public class AlternatingParitySubarrays {
    public static int countAlternatingParitySubarrays(int[] arr, int k) {
        if (arr.length < k) return 0; // Edge case: k is larger than array

        int count = 0;

        // Check the first window manually
        boolean isValid = true;
        for (int i = 1; i < k; i++) {
            if ((arr[i] % 2) == (arr[i - 1] % 2)) {
                isValid = false; // If adjacent numbers have same parity, it's invalid
                break;
            }
        }
        if (isValid) count++;

        // Slide the window
        for (int i = k; i < arr.length; i++) {
            // Remove the leftmost element, add a new element
            if ((arr[i] % 2) == (arr[i - 1] % 2)) {
                isValid = false;
            } else if ((arr[i - k + 1] % 2) == (arr[i - k] % 2)) {
                isValid = true; // Restore validity if only previous head element was invalid
            }

            if (isValid) count++;
        }

        return count;
    }

    public static void main(String[] args) {
        int[] arr = {1, 2, 3, 4, 5, 6, 7, 8};
        int k = 3;
        System.out.println(countAlternatingParitySubarrays(arr, k)); // Output: 6
    }
}