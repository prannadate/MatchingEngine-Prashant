package test;

import java.util.Arrays;
import java.util.HashMap;

public class SimilarWordPairsSorted {

    public static int countPairs(String[] words) {
        HashMap<String, Integer> pairs = new HashMap<>();
        int totalPairs = 0;


        for(String word: words) {
            String formattedWord = getWord(word);
            pairs.put(formattedWord,pairs.getOrDefault(formattedWord, 0) + 1);
        }

        System.out.println("pairs - "+pairs);
        System.out.println("pairs values - "+pairs.values());

        for(int freq: pairs.values()) {
            if(freq > 1) {
                totalPairs+= (freq * (freq -1)) / 2;
            }
        }
        return totalPairs;
    }

    public static String getWord(String word) {
        char[] str = word.toCharArray();
        Arrays.sort(str);
        return new String(str);
    }

    public static void main(String[] args) {
        String[] words1 = {"abc", "bca", "acb", "xyz", "yxz", "zxy", "def"};
        System.out.println(countPairs(words1)); // Output: 6

        String[] words2 = {"hello", "world", "elloh", "dlrow", "abc", "cab"};
        System.out.println(countPairs(words2)); // Output: 3
    }
}
