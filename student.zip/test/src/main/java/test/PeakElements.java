package test;

import java.util.ArrayList;
import java.util.List;

public class PeakElements {

    public static List<Integer> returnResult(int[] arr) {
        List<Integer> result = new ArrayList<>();

        if(arr.length < 3) {
            return result;
        }

        for(int i = 1; i < arr.length - 1; i++) {
            if(arr[i] > arr[i-1] && arr[i] > arr[i+1]) {
                result.add(arr[i]);
            }
        }
        return result;
    }

    public static void main(String args[]) {
        int[] arr = {1, 3, 5, 4, 2, 6, 8, 7};
        System.out.println(returnResult(arr));
    }
}
