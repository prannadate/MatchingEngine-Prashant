package test;

import java.util.ArrayList;
import java.util.List;

public class CrowCollectingSticks {

    public static List<Integer> getResult(int[] forest, int crow) {

      List<Integer> result = new ArrayList<>();
      int stickLength = 0;
      int left = crow -1; int right = crow + 1;

      while (stickLength < 100) {
          boolean collected = false;

          for(int i = 0; i < 2 && left >= 0 && stickLength < 100; i++, left--) {
              if(forest[left] > 0) {
                  stickLength += forest[left];
                  result.add(left);
                  collected = true;
              }
          }

          for(int i = 0; i < 2 && right < forest.length && stickLength < 100; i++, right++) {
              if(forest[right] > 0) {
                  stickLength += forest[right];
                  result.add(right);
                  collected = true;
              }
          }

          if(!collected) break;
      }

      return result;

    }

    public static void main(String args[]) {
        int[] forest = {0, 10, 20, 0, 30, 0, 40, 50, 0, 60};
        int crow = 3;
        System.out.println(getResult(forest, crow));
    }
}
