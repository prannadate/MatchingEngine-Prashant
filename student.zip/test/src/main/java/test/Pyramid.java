package test;

public class Pyramid {
    public static void main(String[] args) {
        int n = 10; // Number of levels for the pyramid
        printPyramid(n);
    }

    public static void printPyramid(int n) {


        for(int i = 0; i < n; i++) {
            // Print leading spaces
            for(int j = 0; j < n - i -1; j++){
                System.out.print(" ");
            }
            // Print asterisks
            for(int k = 0; k < 2 * i + 1; k++){
                System.out.print("*");
            }
            // Move to the next line
            System.out.println();
        }

    }
}
