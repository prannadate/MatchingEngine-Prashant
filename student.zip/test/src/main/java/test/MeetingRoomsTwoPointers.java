package test;

import java.util.Arrays;

public class MeetingRoomsTwoPointers {

    public static int maxMeetingRooms(int[][] intervals) {

        int len = intervals.length;

        int[] startTimes = new int[len];
        int[] endTimes = new int[len];

        for(int i = 0; i < len; i++) {
            startTimes[i] = intervals[i][0];
            endTimes[i] = intervals[i][1];
        }

        Arrays.sort(startTimes);
        Arrays.sort(endTimes);

        int startPtr = 0; int endPtr = 0;
        int rooms = 0; int maxRooms = 0;

        while(startPtr < len) {
            if(startTimes[startPtr] < endTimes[endPtr]) {
                rooms++;
                maxRooms = Math.max(rooms, maxRooms);
                startPtr++;
            } else {
                rooms--;
                endPtr++;
            }
        }
        return maxRooms;
    }

    public static void main(String[] args) {
        int[][] meetings1 = {{0, 30}, {5, 10}, {15, 20}};
        System.out.println(maxMeetingRooms(meetings1)); // Output: 2

        int[][] meetings2 = {{7, 10}, {2, 4}};
        System.out.println(maxMeetingRooms(meetings2)); // Output: 1

        int[][] meetings3 = {{1, 5}, {2, 6}, {8, 9}, {10, 15}, {7, 12}};
        System.out.println(maxMeetingRooms(meetings3)); // Output: 3
    }
}
