import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

public class StreamStringExample {
    public static void main(String[] args) {
        // Input list of strings
        List<String> strings = Arrays.asList("apple", "banana", "cherry", "date", "elderberry");

        // Using Stream and Lambda expressions
        List<String> result = strings.stream()
                .filter(str -> str.length() > 5)         // Filter strings longer than 5 characters
                .map(String::toUpperCase)               // Convert to uppercase
                .sorted()                               // Sort alphabetically
                .collect(Collectors.toList());          // Collect to a new list

        // Print the result
        System.out.println("Processed Strings: " + result);


        List<String> lst = strings.stream()
                .filter(str -> str.length() > 5)
                .map(String::toUpperCase)
                .sorted()
                .collect(Collectors.toList());
    }
}
