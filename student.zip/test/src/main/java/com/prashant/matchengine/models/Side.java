package com.prashant.matchengine.models;

public enum Side {
    BUY,
    SELL
}
