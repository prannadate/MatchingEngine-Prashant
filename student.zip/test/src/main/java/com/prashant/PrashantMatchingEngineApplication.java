package com.prashant;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PrashantMatchingEngineApplication {

	public static void main(String[] args) {
		SpringApplication.run(PrashantMatchingEngineApplication.class, args);
	}
}