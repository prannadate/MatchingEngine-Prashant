package com.prashant.student.service;


import com.prashant.student.model.Student;
import com.prashant.student.repository.StudentRepository;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
public class StudentServiceTest {

    @Mock
    private StudentRepository studentRepository;

    @InjectMocks
    private StudentService studentService;

    @Test
    void shouldGetAllStudents(){

        Student student = new Student(1L, "John", "Scott", "Mechanical", 100.50);

        when(studentRepository.findAll()).thenReturn(List.of(student));

        var response = studentService.getAllStudents();
        assertEquals(1, response.size());
        assertEquals("John", response.get(0).getFirstName());

    }

    @Test
    void testFindByStudentId(){

        Student student = new Student(1L, "John", "Scott", "Mechanical", 100.50);
        when(studentRepository.findById(any())).thenReturn(Optional.of(student));

        Optional<Student> student1 = studentService.getStudentById(1L);
        assertTrue(student1.isPresent());
        assertEquals("John", student1.get().getFirstName());
    }

    @Test
    void testShouldDeleteStudent(){
        Student student = new Student(1L, "John", "Scott", "Mechanical", 100.50);
        when(studentRepository.deleteById(1L)).thenReturn(student);
    }
}









